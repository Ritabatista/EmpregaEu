export const vagas=[
    {titulo:'Engenheiro de Dados', id:1},
    {titulo:'Dev. mobile', id:2},
    {titulo:'Analista de Dados', id:3}
]